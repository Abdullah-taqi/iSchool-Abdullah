export interface Employee{
    _id: string;
    name: string;
    address: string;
    quantity: string;
    process: string;
    
}